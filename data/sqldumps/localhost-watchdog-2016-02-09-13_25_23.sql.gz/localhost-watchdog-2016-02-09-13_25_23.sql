-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Feb 09, 2016 at 01:25 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lectionary`
--

-- --------------------------------------------------------

--
-- Table structure for table `watchdog`
--

CREATE TABLE `watchdog` (
  `wid` int(11) NOT NULL COMMENT 'Primary Key: Unique watchdog event ID.',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The users.uid of the user who triggered the event.',
  `type` varchar(64) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT 'Type of log message, for example "user" or "page not found."',
  `message` longtext NOT NULL COMMENT 'Text of log message to be passed into the t() function.',
  `variables` longblob NOT NULL COMMENT 'Serialized array of variables that match the message string and that is passed into the t() function.',
  `severity` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'The severity level of the event. ranges from 0 (Emergency) to 7 (Debug)',
  `link` text COMMENT 'Link to view the result of the event.',
  `location` text NOT NULL COMMENT 'URL of the origin of the event.',
  `referer` text COMMENT 'URL of referring page.',
  `hostname` varchar(128) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT 'Hostname of the user who triggered the event.',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'Unix timestamp of when event occurred.'
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COMMENT='Table that contains logs of all system events.';

--
-- Dumping data for table `watchdog`
--

INSERT INTO `watchdog` (`wid`, `uid`, `type`, `message`, `variables`, `severity`, `link`, `location`, `referer`, `hostname`, `timestamp`) VALUES
(1, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a353a2264626c6f67223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915855),
(2, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a31383a2264796e616d69635f706167655f6361636865223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915856),
(3, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a383a226669656c645f7569223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915858),
(4, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a373a22686973746f7279223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915859),
(5, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a383a227461786f6e6f6d79223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915862),
(6, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a343a2268656c70223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915864),
(7, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a353a22696d616765223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915865),
(8, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a343a226c696e6b223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915867),
(9, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a31373a226d656e755f6c696e6b5f636f6e74656e74223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915868),
(10, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a373a226d656e755f7569223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915871),
(11, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a31303a22706167655f6361636865223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915873),
(12, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a343a2270617468223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915875),
(13, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a393a22717569636b65646974223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915877),
(14, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a333a22726466223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915878),
(15, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a363a22736561726368223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915880),
(16, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a383a2273686f7274637574223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915883),
(17, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a373a22746f6f6c626172223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915885),
(18, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a353a227669657773223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915887),
(19, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a383a2276696577735f7569223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915889),
(20, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a343a22746f7572223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?_format=json&id=1&langcode=en&op=do&op=do_nojs&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915892),
(21, 0, 'php', '%type: @message in %function (line %line of %file).', 0x613a353a7b733a353a222574797065223b733a373a225761726e696e67223b733a383a22406d657373616765223b4f3a32353a2244727570616c5c436f72655c52656e6465725c4d61726b7570223a313a7b733a393a22002a00737472696e67223b733a3137333a2243616e6e6f74206d6f646966792068656164657220696e666f726d6174696f6e202d206865616465727320616c72656164792073656e7420627920286f75747075742073746172746564206174202f55736572732f636c617564696e652f53697465732f73696e67696e6766726f6d7468656c656374696f6e6172792f76656e646f722f73796d666f6e792f687474702d666f756e646174696f6e2f526573706f6e73652e7068703a33353729223b7d733a393a222566756e6374696f6e223b733a34353a2244727570616c5c436f72655c53657373696f6e5c53657373696f6e4d616e616765722d3e64657374726f792829223b733a353a222566696c65223b733a39383a222f55736572732f636c617564696e652f53697465732f73696e67696e6766726f6d7468656c656374696f6e6172792f7765622f636f72652f6c69622f44727570616c2f436f72652f53657373696f6e2f53657373696f6e4d616e616765722e706870223b733a353a22256c696e65223b693a3236373b7d, 4, '', 'http://singingfromthelectionary.local:8888/core/install.php/?id=1&langcode=en&op=do_nojs&op=finished&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915893),
(22, 0, 'system', '%theme theme installed.', 0x613a313a7b733a363a22257468656d65223b733a363a22737461626c65223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?langcode=en&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915894),
(23, 0, 'system', '%theme theme installed.', 0x613a313a7b733a363a22257468656d65223b733a363a22636c61737379223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?langcode=en&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915894),
(24, 0, 'system', '%theme theme installed.', 0x613a313a7b733a363a22257468656d65223b733a363a2262617274696b223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?langcode=en&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915894),
(25, 0, 'system', '%theme theme installed.', 0x613a313a7b733a363a22257468656d65223b733a353a22736576656e223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?langcode=en&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915894),
(26, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a383a227374616e64617264223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?langcode=en&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard&id=1&op=start', '::1', 1454915898),
(27, 0, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a363a22757064617465223b7d, 6, '', 'http://singingfromthelectionary.local:8888/core/install.php/?langcode=en&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard', '::1', 1454915944),
(28, 0, 'cron', 'Cron run completed.', 0x613a303a7b7d, 5, '', 'http://singingfromthelectionary.local:8888/core/install.php/?langcode=en&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard', '::1', 1454915947),
(29, 1, 'user', 'Session opened for %name.', 0x613a313a7b733a353a22256e616d65223b733a353a2261646d696e223b7d, 5, '', 'http://singingfromthelectionary.local:8888/core/install.php/?langcode=en&profile=standard&rewrite=ok&rewrite=ok', 'http://singingfromthelectionary.local:8888/core/install.php?rewrite=ok&langcode=en&profile=standard', '::1', 1454915947),
(30, 0, 'cron', 'Cron run completed.', 0x613a303a7b7d, 5, '', 'http://singingfromthelectionary.local:8888/', '', '::1', 1454984116),
(31, 1, 'system', '%module module installed.', 0x613a313a7b733a373a22256d6f64756c65223b733a31343a226261636b75705f6d696772617465223b7d, 6, '', 'http://singingfromthelectionary.local:8888/admin/modules', 'http://singingfromthelectionary.local:8888/admin/modules', '::1', 1454984184),
(32, 1, 'php', '%type: @message in %function (line %line of %file).', 0x613a353a7b733a353a222574797065223b733a363a224e6f74696365223b733a383a22406d657373616765223b4f3a32353a2244727570616c5c436f72655c52656e6465725c4d61726b7570223a313a7b733a393a22002a00737472696e67223b733a32343a22556e646566696e656420696e6465783a207061636b616765223b7d733a393a222566756e6374696f6e223b733a32313a2273797374656d5f726571756972656d656e74732829223b733a353a222566696c65223b733a38353a222f55736572732f636c617564696e652f53697465732f73696e67696e6766726f6d7468656c656374696f6e6172792f7765622f636f72652f6d6f64756c65732f73797374656d2f73797374656d2e696e7374616c6c223b733a353a22256c696e65223b693a35373b7d, 5, '', 'http://singingfromthelectionary.local:8888/admin/config', 'http://singingfromthelectionary.local:8888/admin/modules', '::1', 1454984302),
(33, 0, 'DrupalKernel', 'Container cannot be saved to cache.', 0x613a303a7b7d, 5, '', '', '', '', 1454984427),
(34, 0, 'DrupalKernel', 'Container cannot be saved to cache.', 0x613a303a7b7d, 5, '', '', '', '', 1454984432),
(35, 0, 'DrupalKernel', 'Container cannot be saved to cache.', 0x613a303a7b7d, 5, '', '', '', '', 1454984518);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `watchdog`
--
ALTER TABLE `watchdog`
  ADD PRIMARY KEY (`wid`),
  ADD KEY `type` (`type`),
  ADD KEY `uid` (`uid`),
  ADD KEY `severity` (`severity`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `watchdog`
--
ALTER TABLE `watchdog`
  MODIFY `wid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique watchdog event ID.',AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
